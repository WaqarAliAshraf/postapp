import React from "react";
import img from "../images/banner-image.png";

const Banner = () => {
  return (
    <div className="banner-wrapper">
      <div className="container">
        <div className="row">
          <div className="col-5">
            <h1>
              Articles for <br />
              <span>front-end devs</span>
            </h1>
            <p>Articles on web performance, responsive web design and more</p>
          </div>
          <div className="col-7">
            <img src={img} alt="" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
